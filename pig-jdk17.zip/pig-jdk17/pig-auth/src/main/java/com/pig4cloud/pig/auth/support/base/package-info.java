/**
 * 自定义认证模式接入的抽象实现
 */
package com.pig4cloud.pig.auth.support.base;
