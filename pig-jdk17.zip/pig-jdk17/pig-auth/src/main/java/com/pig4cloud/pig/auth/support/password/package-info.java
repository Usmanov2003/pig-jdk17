/**
 * 密码模式
 */
package com.pig4cloud.pig.auth.support.password;
